// 离线预置示例插件：把宿主（Node 侧）的运行时信息通过 rpc 暴露出来。
// 只读内置模块，没有网络请求，卸载后端点随 dispose 一起消失。
import os from 'node:os'

export const name = 'dsh-offline-whoami'
export const inject = []

export function apply(ctx) {
  const connection = ctx.get('connection')
  return connection?.rpc.handle('/whoami', async (endpoint) => {
    if (endpoint === undefined || endpoint === null || endpoint === 'whoami') {
      return {
        plugin: name,
        host: os.hostname(),
        platform: os.platform(),
        release: os.release(),
        node: process.version,
        pid: process.pid,
        uptimeSeconds: Math.round(process.uptime()),
      }
    }
    return { endpoints: ['whoami'] }
  })
}
