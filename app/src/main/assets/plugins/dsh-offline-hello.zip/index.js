// 离线预置示例插件：不联网、不依赖任何 npm 包，只用 Node 内置模块。
// 刻意 import 'node:os' —— plugin-host 的 classifyPlugin 看到 node: 依赖会把包判成
// Node 宿主插件（PluginKind.Node），交给 NodeBackedPlugin 的 plugins.load，
// 而不是塞进 Rhino。这是「能被现有 plugin-host 加载」的最小可运行形状。
import os from 'node:os'

export const name = 'dsh-offline-hello'
export const inject = []

export function apply(ctx) {
  const connection = ctx.get('connection')
  // rpc.handle 返回 dispose；插件的 apply 返回它，卸载时会自动摘掉这个端点。
  const dispose = connection?.rpc.handle('/hello', async (endpoint) => {
    if (endpoint === undefined || endpoint === null || endpoint === 'whoami') {
      return {
        hello: 'world',
        plugin: name,
        platform: os.platform(),
        arch: os.arch(),
        at: Date.now(),
      }
    }
    return { endpoints: ['whoami'] }
  })
  return dispose
}
