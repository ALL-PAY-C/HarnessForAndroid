# 破甲插件（Android 数据插件）

冷咖啡 / LilCode 破甲提示词组的 **App 侧产物**。同目录的 `../dist/dsh-sauce-packs-0.1.0.zip` 是给
Node 引擎 / 技能管理器用的（`package.json` + `index.js` + `packs/`），App 的「插件」页不认它——
App 只认 `plugin.json`（`PluginManifestFile`）。这份产物就是补那一条。

## 包内结构

```
dsh-sauce-packs-0.1.0-android/     <- zip 单一顶层目录，安装器会把它提平
├── plugin.json                    <- id / name / version / config / ui / contributions
├── index.js                       <- Rhino 入口：按 ctx.config 的开关注册 slot 贡献
└── README.md
```

## 开关（plugin.json 的 config）

| key | 标签 | 类型 | 默认 | 作用 |
| --- | --- | --- | --- | --- |
| `coldcoffee` | 冷咖啡破甲 | switch | true | 注册「+」里的 `破甲：冷咖啡` |
| `lilcode` | LilCode 破甲 | switch | true | 注册「+」里的 `破甲：LilCode` |
| `autoReply` | 自动激活回复 | switch | false | 注册「先回激活行再开干」入口 |
| `injectPreset` | 注入预设 | switch | true | 注册「冷咖啡 + LilCode 合并注入」入口 |
| `presetMode` | 预设档位 | select | full | lite / full / ultra，写进上面两条提示词 |

开关在「设置 → 插件 → 破甲插件」里；关掉设置页触发 `reloadPlugins()`，`index.js` 重跑，
新状态立刻生效。

## 贡献的槽位

- `chat.composer.plus`：四个提示词入口（受开关控制，全关就一个都没有）。
- `chat.settings`：`sauce.packs.panel` 状态卡 —— 会话设置「添加到会话设置」里能选到它。
- `plugin.page`：宿主自动从 `plugin.json` 根上的 `ui` 生成，插件详情里那张卡。

## 出包

```bash
node build-android-zip.mjs
# -> dist/dsh-sauce-packs-0.1.0-android.zip
```
## 验证记录（emulator-5554 / dev.dsh.mobile.debug）

- 安装：插件 → 插件安装 → 文件安装 → Downloads 选 zip；日志 `ext plugin installed: dev.dsh.sauce.packs`、`执行完成：贡献 4`。
- 开关：插件 → 插件管理 → 破甲插件 → 「插件设置」四项 switch + 预设档位，改完即 `reloadPlugins()`。
- 会话设置：设置 → 应用与更新 → 拓展 → 打开「拓展插件ui配置」（= `SlotEditState.enabled`），会话菜单进「会话设置」→「+ 添加插件组件」，候选里五个贡献全在。
- 单测：`gradlew.bat --offline :plugin-host:testDebugUnitTest --tests '*SaucePacksAndroidPluginTest'` → tests=4 failures=0。
- 截图：`../screenshots/01-plugin-list.png` … `09-plugin-list-enabled.png`。

> 宿主注意：`PluginSettingsScreen` 外层已有 `verticalScroll`，插件 `ui` 里再写 `"scrollable": true` 会触发
> Compose `CheckScrollableContainerConstraints` 崩溃（实测）。本插件已去掉该键。
